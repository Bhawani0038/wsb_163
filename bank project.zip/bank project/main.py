import bank_management_class as bmc

def main():
    obj = bmc.BankManagement()

if __name__ == '__main__':
    main()