import json

class AccountPasswordVerifier():
    def __init__(self):
        pass
             
    def account_no_generator(self):
        """this function will generate 7 digits account number"""
        import random
        accc_no = ''.join(random.choices("0987654321", k = 7))
        return accc_no
        
    def password_strength_checker(self):
        from zxcvbn import zxcvbn
        while True:
            password =input("password:")
            result = zxcvbn(password)

            if result['score'] >= 3:
                print("strong password has been set up.......")
                return password
            else:
                print("Feedback:", result['feedback']['warning'])
    
    def email_verifier(self):
        from email_validator import validate_email, EmailNotValidError
        while True:
            email = input("email:")

            try:
                # Validate.
                valid = validate_email(email)
                print("Valid email:", valid.email)
                return email
                
            except EmailNotValidError as e:
                print("Invalid email:", str(e))
      
    def phone_verifier(self):
        invalid_phone_number = True
        while invalid_phone_number:
            phone_no = input("Phone Number:")
            if len(phone_no) == 10 and phone_no.isdigit():
                return phone_no
            
            else:
                print("Invalid Phone Number")  
                  
    def dob_verifier(self):
        from datetime import datetime
        while True:
            try:
                dob_str  = input("DOB:")
                # Parse the input string using dd-mm-yyyy format
                dob = datetime.strptime(dob_str, "%d-%m-%Y")
                today = datetime.today()

                # Future date check
                if dob > today:
                    return "❌ Invalid: Date of birth is in the future."

                # Age check (realistic max 150 years)
                age = (today - dob).days // 365
                if age > 110:
                    print(f"❌ Invalid: Age {age} is unrealistic.")

                return dob_str

            except ValueError:
                print("❌ Invalid: Date format should be dd-mm-yyyy or date does not exist.")

class BankManagement():
    def __init__(self):
        self.load_database_or_create_database()
        self.HomeWindow()

    def load_database_or_create_database(self):
        try:
            with open('database.json', 'r') as f:
                self.db = json.load(f)
                
        except FileNotFoundError:
            with open('database.json', 'w') as f:
                json.dump({}, f)
            
            with open('database.json', 'r') as f:
                self.db = json.load(f)
      
    def sign_up(self):
        apv = AccountPasswordVerifier()
        user_info = {
            "name"            : input("name:"),
            "email"           : apv.email_verifier(),
            "phone no"        : apv.phone_verifier(),
            "password"        : apv.password_strength_checker(),
            "dob"             : apv.dob_verifier(),
            "balance"         : 0,
            "account_no"      : apv.account_no_generator(),
        }
        self.db[user_info["account_no"]]  = user_info    
        print("data create sucessfully", user_info)
        
        with open('database.json', 'w') as f:
            json.dump(self.db, f)
                   
    def HomeWindow(self):
        choice = input(
            """
                1: SignUp
                2: Login
                3: Exit
            """
        )
        if choice == "1":
            self.sign_up()
        
        elif choice == "2":
            self.login()
        
        elif choice == "3":
            print("eixting the app.........")
            exit()

    def login(self):
        login_acc_no = input("Acc No:  ")  #4358583
         
        if login_acc_no not in self.db:
            print("account doesn't exist ")
            print("exit the app..........")
            exit()
        else:
            login_password = input("Password:   ")
            password_from_db = self.db[login_acc_no]["password"]
            if login_password == password_from_db:
                bank_obj  = self
                cu_obj = CustomerPortal(bank_obj,login_acc_no)
                
            
            else:
                print("password wrong")
            
class CustomerPortal():
    def __init__(self, BankObject,login_acc_no):
        self.login_acc_no = login_acc_no
        self.db = BankObject.db
        print("--------CUSTOMER WINDOW-----------")
        while True:
            choice = input("""
                        1: Check Balance
                        2: Withdraw Balance
                        3: Deposit Balance
                        4: Change Password
                        5: Transfer money
                        6: Exit
                        """
                    )
            if choice == "1":
                print("Your current balance =", self.check_balance())
            
            elif choice == "2":
                self.withdraw()
                
            elif choice == "3":
                self.deposit_money()
                
            elif choice == "4":
                self.change_password() 
            
            elif choice == "5":
                self.transfer_money()
            
            elif choice == "6":
                print("exiting the app............")
                exit()
                          
    def check_balance(self):
        return self.db[self.login_acc_no]['balance']
        
    def withdraw(self):
        amount = float(input("Amount:"))
        bank_balance = self.check_balance()
        if amount <= 0:
            print("Negative OR ZERO amount can't be withdrawn")
        
        elif amount > bank_balance:
            print("insufficient balance....")
        
        else:
            bank_balance -= amount  #bank_balance = bank_balanc  - amount
            self.db[self.login_acc_no]["balance"] = bank_balance
            self.make_changes_to_db()
            print(f"Rs {amount = } Withdrawn succesfully.  Remaining Balance = ", self.check_balance())

    def deposit_money(self):
        amount = float(input("Amount:"))
        if amount >= 0:
            bank_balance = self.check_balance()
            bank_balance += amount  #bank_balance = bank_balance + amount
            self.db[self.login_acc_no]["balance"] = bank_balance
            self.make_changes_to_db()
            print(f"Rs {amount = } Depsoited succesfully. Updated Balance = ", self.check_balance())
        
        else:
            print("invalid amount.....")
        
    def change_password(self):
        new_password = AccountPasswordVerifier().password_strength_checker()
        self.db[self.login_acc_no]["password"] = new_password
        self.make_changes_to_db()
        print(f"password changed {new_password =}")
        
    def transfer_money(self):
        reciever_account_no = input("account no:  ")
        if reciever_account_no not in self.db:
            print("not a valid account....")
        else:
            reciever_balance = self.db[reciever_account_no]["balance"]
            user_balance =self.check_balance()
            amount = float(input("Transfer amount: "))
            if amount >= 0 and amount <= user_balance:
                user_balance -= amount
                reciever_balance  += amount
                self.db[self.login_acc_no]["balance"] = user_balance
                self.db[reciever_account_no]["balance"] = reciever_balance
                self.make_changes_to_db()
                print(f"Rs{amount} transfeered su ccesfully New balance = {user_balance}")
            
            elif amount <= 0:
                print("negative or zero amount can't be transeferd")
            
            elif amount > user_balance:
                print("insuffcicient aamount")
        
    def make_changes_to_db(self):
        with open("database.json", "w")  as f:
            json.dump(self.db, f)