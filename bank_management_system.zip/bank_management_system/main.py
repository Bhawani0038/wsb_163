import json


#This is useful to load data from database
with open("database.json", "r") as f:
    bank_database = json.load(f)

class Bank:
    def __init__(self):
        self.home_window()

    #to make chaneges in database
    def commit_changes_to_db(self):
        with open("database.json","w") as f:
            json.dump(bank_database, f)


    def home_window(self):
        print("-----------------Bank Home Window-------------------------")
        choice = input("""
                    1: Login
                    2: Sign Up
                    3: Exit
        """)

        if choice == "1":
            self.login()
 
        
        elif choice == "2":
            self.sign_up()

        elif choice == "3":
            exit()
        
        else:
            print("invalid input.......")


    def login(self):
        print("------------------Login Panel-------------------")
        login_time_email = input("email id:")
        account_no = input("account_no:")
        login_time_password = input("password:")
        mail_id_from_server = bank_database.get(account_no, {}).get("mail_id", {})
        password_from_server =  bank_database.get(account_no, {}).get("password", {})

        if mail_id_from_server == login_time_email and  password_from_server == login_time_password:
            print("--------------LOGIN SUCCESSFULL----------------")
            self.user_access_panel(account_no)
        else:
            print("invalid credential")
            exit()



    def sign_up(self):
        print("------------------Signup Panel-------------------")
        user_data = {
            "name"      : input("name        "),
            "dob"       : input("dob        "),
            "phone"     : input("phone        "),
            "address"   : input("address        "),
            "mail_id"   : input("mail_id        "),
            "adhaar"    : input("adhaar        "),
            "password"  : input("password        "),
            "balance"   : 0 
        }
        
        account_no = self.gen_random_account_no()
        while True:
            if account_no not in bank_database:
                bank_database[account_no] = user_data
                self.commit_changes_to_db()
                print(f"Account created succesfully. Account no = {account_no} and password = {user_data["password"]}")

                break
            else:
                account_no = self.gen_random_account_no()

    def check_balance(self):
        return self.user_data.get("balance" , {})

    def withdraw(self, account_no):
        amount = float(input("Amount to withdraw:"))
        bank_balance = self.check_balance()
        if amount > bank_balance:
            print("Insufficient amount.....")
        
        elif amount < 0:
            print("Please insert positive amount only")
        
        else:
            bank_balance = bank_balance - amount
            self.user_data['balance'] = bank_balance
            bank_database[account_no] = self.user_data
            self.commit_changes_to_db()
            print(f"Rs {amount} withdrawn successfully. New Balance = ", self.check_balance())

    def transfer_money(self, account_no):
        reciever_account_no = input("Reciever's account no:") 
        amount = float(input("Amount to transfer:")) 
        if reciever_account_no in bank_database:
            amount = float(input("Amount to transfer:")) 
            user_balance = self.check_balance()
            reciever_balance = bank_database.get(reciever_account_no, {}).get("balance")
            user_balance = user_balance - amount
            reciever_balance = reciever_balance + amount
            bank_database[reciever_account_no]['balance'] = reciever_balance
            bank_database[account_no]['balance'] = user_balance
            self.commit_changes_to_db()
            print(f"Rs {amount} transefeered succcessllsdfsf uodate balaNCE =", self.check_balance())

        else:
            print("account no not exist")

    def deposit(self, account_no):

        amount = float(input("Amount:")) 
        bank_balance = self.check_balance() 
        if amount >= 0:
            bank_balance = bank_balance + amount 
            self.user_data['balance'] = bank_balance
            bank_database[account_no] = self.user_data
            self.commit_changes_to_db()
            print(f"Rs {amount} deposited successfully. New Balance = ", self.check_balance())
        else:
            print("invalid amount")

    def change_password(self, account_no):
        new_password = input("Enter new password")
        bank_database[account_no]['password'] = new_password
        self.commit_changes_to_db()
        print("password changed successfully. New password = ", new_password)

    def gen_random_account_no(self):
        import random
        return ''.join(random.choices("0987654321", k = 7))
    
    def user_access_panel(self, account_no):
        self.user_data = bank_database.get(account_no, {})
        while True:
            choice = input("""
                1: Check Balance
                2: Withdraw Money
                3: Deposit Money
                4: Transfer Money
                5: Change Password
                6: Exit
                """)
            
            if choice == "1":
                print("Current balance = ", self.check_balance())

            elif choice == "2":
                self.withdraw(account_no)

            elif choice == "3":
                self.deposit(account_no)

            elif choice == "4":
                self.transfer_money(account_no)

            elif choice == "5":
                self.change_password(account_no)

            elif choice == "6":
                break


b = Bank()
