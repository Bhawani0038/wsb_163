from flask import Flask, request, render_template
import mysql.connector

app = Flask(__name__)

# MySQL Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',
    'database': 'employee_db'
}

@app.route('/')
def form():
    return render_template("form.html")

@app.route('/submit', methods=['POST'])
def submit():
    emp_id = request.form['emp_id']
    name = request.form['name']
    department = request.form['department']
    gender = request.form['gender']
    salary = request.form['salary']
    doj = request.form['doj']

    # Connect to MySQL and insert
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        insert_query = """
            INSERT INTO employee_data (emp_id, name, department, gender, salary, date_of_joining)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (emp_id, name, department, gender, salary, doj))
        conn.commit()

        return "<h3>Data inserted successfully into MySQL!</h3>"

    except mysql.connector.Error as err:
        return f"<h3>Error: {err}</h3>"

    finally:
        if cursor: cursor.close()
        if conn: conn.close()

if __name__ == "__main__":
    app.run(debug=True)
